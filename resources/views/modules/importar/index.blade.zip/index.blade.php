<x-app-layout>
    <x-slot name="header">
        <x-profile.profile-title icon="document-arrow-up" title="Importar Usuarios desde Excel" />
    </x-slot>

    <div class="py-6 mx-auto max-w-7xl sm:px-6 lg:px-8">
        <!-- Sección de Instrucciones -->
        <div class="mb-6">
            @include('modules.usuarios.partials.import-info')
        </div>

        <!-- Alertas y Mensajes -->
        <div class="mb-6">
            @if (session('success'))
                <div class="p-4 mb-4 border border-green-200 rounded-md bg-green-50" role="alert" aria-live="polite">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <svg class="w-5 h-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-green-800">Importación Exitosa</h3>
                            <p class="mt-1 text-sm text-green-700">{{ session('success') }}</p>
                            @if (session('import_results'))
                                <div class="mt-2 text-sm text-green-700">
                                    <ul class="list-disc list-inside">
                                        <li>Usuarios importados: {{ session('import_results')['imported'] }}</li>
                                        <li>Usuarios actualizados: {{ session('import_results')['updated'] }}</li>
                                        @if (session('import_results')['skipped'] > 0)
                                            <li>Usuarios omitidos: {{ session('import_results')['skipped'] }}</li>
                                        @endif
                                    </ul>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            @endif

            @if (session('error'))
                <div class="p-4 mb-4 border border-red-200 rounded-md bg-red-50" role="alert" aria-live="assertive">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <svg class="w-5 h-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-red-800">Error en la Importación</h3>
                            <p class="mt-1 text-sm text-red-700">{{ session('error') }}</p>
                        </div>
                    </div>
                </div>
            @endif
        </div>

        <!-- Formulario Principal -->
        <div class="bg-white rounded-lg shadow">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-medium text-gray-900">Importación de Usuarios</h2>
                <p class="mt-1 text-sm text-gray-600">Seleccione un archivo Excel para importar usuarios masivamente</p>
            </div>

            <div class="px-6 py-4">
                <!-- Formulario de Subida -->
                <form id="import-form" action="{{ route('admin.usuarios.import.preview') }}" method="POST" enctype="multipart/form-data">

                    @csrf

                    <!-- Selección de Archivo -->
                    <div class="mb-6">
                        <label for="archivo" class="block mb-2 text-sm font-medium text-gray-700">
                            Archivo Excel <span class="text-red-500">*</span>
                        </label>
                        <div class="flex items-center justify-center w-full">
                            <label for="archivo" class="flex flex-col items-center justify-center w-full h-32 transition-colors duration-200 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                                <div class="flex flex-col items-center justify-center pt-5 pb-6">
                                    <svg class="w-8 h-8 mb-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                                    </svg>
                                    <p class="mb-2 text-sm text-gray-500">
                                        <span class="font-semibold">Clic para seleccionar archivo</span> o arrastre aquí
                                    </p>
                                    <p class="text-xs text-gray-500">XLSX, XLS o CSV (máx. 10MB)</p>
                                </div>
                                <input id="archivo" name="archivo" type="file" class="hidden" accept=".xlsx,.xls,.csv" required>
                            </label>
                        </div>
                        <div id="file-info" class="hidden mt-2 text-sm text-gray-600">
                            <span id="file-name"></span> (<span id="file-size"></span>)
                        </div>
                    </div>

                    <!-- Opciones de Importación -->
                    <div class="mb-6">
                        <h3 class="mb-3 text-sm font-medium text-gray-900">Opciones de Importación</h3>
                        <div class="space-y-3">
                            <div class="flex items-center">
                                <input id="actualizar_existentes" name="actualizar_existentes" type="checkbox" class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                                <label for="actualizar_existentes" class="block ml-2 text-sm text-gray-900">
                                    Actualizar usuarios existentes
                                </label>
                            </div>
                            <div class="flex items-center">
                                <input id="enviar_notificaciones" name="enviar_notificaciones" type="checkbox" class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                                <label for="enviar_notificaciones" class="block ml-2 text-sm text-gray-900">
                                    Enviar notificaciones por correo
                                </label>
                            </div>
                            <div class="flex items-center">
                                <input id="cambiar_password" name="cambiar_password" type="checkbox" class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" checked>
                                <label for="cambiar_password" class="block ml-2 text-sm text-gray-900">
                                    Requerir cambio de contraseña en primer acceso
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Botones de Acción -->
                    <div class="flex items-center justify-between">
                        <a href="{{ route('admin.usuarios.downloadTemplate') }}"
                           class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 transition-colors duration-200 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                            Descargar Plantilla
                        </a>

                        <button type="submit" id="preview-btn"
                                class="inline-flex items-center px-6 py-2 text-sm font-medium text-white transition-colors duration-200 bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                            </svg>
                            Vista Previa
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Sección de Vista Previa -->
        <div id="preview-section" class="hidden mt-6">
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h3 class="text-lg font-medium text-gray-900">Vista Previa de Importación</h3>
                    <p class="mt-1 text-sm text-gray-600">Revise los datos antes de confirmar la importación</p>
                </div>

                <div class="px-6 py-4">
                    <!-- Estadísticas de Vista Previa -->
                    <div id="preview-stats" class="grid grid-cols-1 gap-4 mb-6 md:grid-cols-4">
                        <div class="p-4 rounded-lg bg-blue-50">
                            <div class="text-2xl font-bold text-blue-600" id="total-records">0</div>
                            <div class="text-sm text-blue-800">Total Registros</div>
                        </div>
                        <div class="p-4 rounded-lg bg-green-50">
                            <div class="text-2xl font-bold text-green-600" id="valid-records">0</div>
                            <div class="text-sm text-green-800">Registros Válidos</div>
                        </div>
                        <div class="p-4 rounded-lg bg-red-50">
                            <div class="text-2xl font-bold text-red-600" id="invalid-records">0</div>
                            <div class="text-sm text-red-800">Con Errores</div>
                        </div>
                        <div class="p-4 rounded-lg bg-yellow-50">
                            <div class="text-2xl font-bold text-yellow-600" id="duplicate-records">0</div>
                            <div class="text-sm text-yellow-800">Duplicados</div>
                        </div>
                    </div>

                    <!-- Tabs de Vista Previa -->
                    <div class="border-b border-gray-200">
                        <nav class="flex -mb-px space-x-8" aria-label="Tabs">
                            <button id="tab-valid" class="px-1 py-2 text-sm font-medium text-blue-600 border-b-2 border-blue-500 tab-button active whitespace-nowrap" type="button">
                                Registros Válidos
                            </button>
                            <button id="tab-errors" class="px-1 py-2 text-sm font-medium text-gray-500 border-b-2 border-transparent tab-button whitespace-nowrap hover:text-gray-700 hover:border-gray-300" type="button">
                                Errores
                            </button>
                            <button id="tab-warnings" class="px-1 py-2 text-sm font-medium text-gray-500 border-b-2 border-transparent tab-button whitespace-nowrap hover:text-gray-700 hover:border-gray-300" type="button">
                                Advertencias
                            </button>
                        </nav>
                    </div>

                    <!-- Contenido de Tabs -->
                    <div id="tab-content" class="mt-4">
                        <div id="content-valid" class="tab-content">
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Fila</th>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Nombre</th>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Email</th>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Documento</th>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Estado</th>
                                        </tr>
                                    </thead>
                                    <tbody id="valid-records-tbody" class="bg-white divide-y divide-gray-200">
                                        <!-- Contenido dinámico -->
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div id="content-errors" class="hidden tab-content">
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Fila</th>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Campo</th>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Error</th>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Valor</th>
                                        </tr>
                                    </thead>
                                    <tbody id="error-records-tbody" class="bg-white divide-y divide-gray-200">
                                        <!-- Contenido dinámico -->
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div id="content-warnings" class="hidden tab-content">
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Fila</th>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Tipo</th>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Mensaje</th>
                                            <th scope="col" class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Datos</th>
                                        </tr>
                                    </thead>
                                    <tbody id="warning-records-tbody" class="bg-white divide-y divide-gray-200">
                                        <!-- Contenido dinámico -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Formulario de Confirmación -->
                    <form id="confirm-import-form" action="{{ route('admin.usuarios.import') }}" method="POST" class="mt-6">
                        @csrf
                        <input type="hidden" name="temp_file" id="temp-file-input">
                        <input type="hidden" name="actualizar_existentes" id="hidden-actualizar-existentes">
                        <input type="hidden" name="enviar_notificaciones" id="hidden-enviar-notificaciones">
                        <input type="hidden" name="cambiar_password" id="hidden-cambiar-password">

                        <div class="flex items-center justify-between">
                            <button type="button" id="cancel-import"
                                    class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 transition-colors duration-200 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                                </svg>
                                Cancelar
                            </button>

                            <button type="submit" id="confirm-import-btn"
                                    class="inline-flex items-center px-6 py-2 text-sm font-medium text-white transition-colors duration-200 bg-green-600 border border-transparent rounded-md shadow-sm hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed">
                                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                Confirmar Importación
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Sección de Progreso -->
        <div id="progress-section" class="hidden mt-6">
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h3 class="text-lg font-medium text-gray-900">Progreso de Importación</h3>
                </div>
                <div class="px-6 py-4">
                    <div class="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                        <div id="progress-bar" class="bg-blue-600 h-2.5 rounded-full transition-all duration-300" style="width: 0%"></div>
                    </div>
                    <div class="flex justify-between text-sm text-gray-600">
                        <span id="progress-text">Iniciando importación...</span>
                        <span id="progress-percentage">0%</span>
                    </div>
                    <div id="progress-logs" class="p-3 mt-4 overflow-y-auto rounded-md max-h-32 bg-gray-50">
                        <div class="font-mono text-sm text-gray-600">
                            <div>Preparando importación...</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="{{ asset('js/modules/usuarios/import.js') }}"></script>
    <script>
        // Inicializar funcionalidad de importación
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof UsuariosImport !== 'undefined') {
                UsuariosImport.init();
            }
        });
    </script>
</x-app-layout>
